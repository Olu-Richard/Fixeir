<?php

declare(strict_types=1);

/**
 * This file is part of CodeIgniter 4 framework.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace CodeIgniter\CLI;

/**
 * Input and Output for CLI.
 */
class InputOutput
{
    /**
     * Is the readline library on the system?
     */
    private readonly bool $readlineSupport;

    private bool $atEnd = false;

    public function __construct()
    {
        // Readline is an extension for PHP that makes interactivity with PHP
        // much more bash-like.
        // http://www.php.net/manual/en/readline.installation.php
        $this->readlineSupport = extension_loaded('readline');
    }

    /**
     * Get input from the shell, using readline or the standard STDIN
     *
     * Named options must be in the following formats:
     * php index.php user -v --v -name=John --name=John
     *
     * @param string|null $prefix You may specify a string with which to prompt the user.
     */
    public function input(?string $prefix = null): string
    {
        // readline() can't be tested.
        if ($this->readlineSupport && ENVIRONMENT !== 'testing') {
            // @codeCoverageIgnoreStart
            $prompt = $this->readlinePrompt($prefix, readline_info('library_version'));

            if ($prompt === null) {
                // The library cannot render the prompt, so write it ourselves and let readline() only read the line.
                self::fwrite(STDOUT, $prefix ?? '');
            }

            $input       = readline($prompt);
            $this->atEnd = $input === false && (! defined('STDIN') || ! stream_isatty(STDIN));

            return $input === false ? '' : $input;
            // @codeCoverageIgnoreEnd
        }

        // self:: skips MockInputOutput's fwrite override, whose filter bookkeeping must not nest inside input().
        self::fwrite(STDOUT, $prefix ?? '');

        $stdin       = fopen('php://stdin', 'rb');
        $input       = fgets($stdin);
        $this->atEnd = $input === false && ! stream_isatty($stdin);

        if ($input === false) {
            return '';
        }

        return $input;
    }

    /**
     * Whether the last `input()` found the end of an input other than a terminal,
     * so that no later read can bring an answer. At a terminal, `Ctrl+D` ends only
     * the current read, and `input()` returns an empty string as for an empty line.
     */
    public function isAtEnd(): bool
    {
        return $this->atEnd;
    }

    /**
     * While the library is intended for use on CLI commands,
     * commands can be called from controllers and elsewhere
     * so we need a way to allow them to still work.
     *
     * For now, just echo the content, but look into a better
     * solution down the road.
     *
     * @param resource $handle
     */
    public function fwrite($handle, string $string): void
    {
        if (! is_cli()) {
            echo $string;

            return;
        }

        fwrite($handle, $string);
    }

    /**
     * Builds the prompt handed to readline(), or returns null when the caller has to write
     * the prompt to STDOUT itself because the line-editing library cannot render it.
     *
     * GNU readline gets ANSI sequences wrapped in its non-printing markers so line-redraw
     * column accounting skips them. Libedit reports "EditLine wrapper" and mangles the
     * markers, so it gets the raw prompt. Windows builds use WinEditLine, which prints ANSI
     * sequences literally, and readline_info() omits the version there (php-src guards it
     * with #ifndef PHP_WIN32), so they get no prompt.
     *
     * @param mixed $libraryVersion The value of readline_info('library_version')
     */
    private function readlinePrompt(?string $prefix, mixed $libraryVersion): ?string
    {
        if ($prefix === null || ! is_string($libraryVersion)) {
            return null;
        }

        if (str_contains($libraryVersion, 'EditLine')) {
            return $prefix;
        }

        return $this->markAnsiNonPrinting($prefix);
    }

    /**
     * Wraps ANSI escape sequences in readline's non-printing markers so line-redraw column accounting skips them.
     */
    private function markAnsiNonPrinting(string $prefix): string
    {
        return preg_replace('/(\e\[[0-9;]*m)/', "\x01\$1\x02", $prefix);
    }
}
